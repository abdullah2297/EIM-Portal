'use client';

import { useMemo, useState } from 'react';
import { achievementsService, employeesService, teamsService } from '@/services';
import { useAsyncData } from '@/hooks/useAsyncData';
import { useDebouncedValue } from '@/hooks/useDebouncedValue';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { ChipFilters, SearchInput } from '@/components/ui/Fields';
import { DataState, EmptyState } from '@/components/ui/StateViews';
import { StatTile } from '@/components/ui/StatTile';
import { Timeline } from '@/components/ui/Timeline';
import { Badge } from '@/components/ui/Badge';
import { Avatar } from '@/components/ui/Avatar';
import { AchievementCard } from '@/components/cards/AchievementCard';
import { ACHIEVEMENT_CATEGORIES } from '@/lib/constants';

const ALL = 'all';

/**
 * Achievements board: highlights, filterable award grid, per-audience
 * groupings (employee / team / department) and a recognition timeline.
 */
export function AchievementsBoard() {
  const [term, setTerm] = useState('');
  const [category, setCategory] = useState(ALL);
  const debouncedTerm = useDebouncedValue(term, 250);

  const { data: reference } = useAsyncData(async () => {
    const [teams, employees] = await Promise.all([
      teamsService.list({ sort: 'order', order: 'asc' }),
      employeesService.list(),
    ]);
    return { teams: teams.items, employees: employees.items };
  }, []);

  const teams = useMemo(() => reference?.teams ?? [], [reference]);
  const employees = useMemo(() => reference?.employees ?? [], [reference]);
  const teamsById = useMemo(() => Object.fromEntries(teams.map((t) => [t.id, t])), [teams]);
  const employeesById = useMemo(() => Object.fromEntries(employees.map((e) => [e.id, e])), [employees]);

  const { data, error, isLoading, refetch } = useAsyncData(
    () =>
      achievementsService.list({
        q: debouncedTerm,
        category,
        sort: 'date',
        order: 'desc',
      }),
    [debouncedTerm, category],
  );

  const achievements = useMemo(() => data?.items ?? [], [data]);

  const highlights = achievements.filter((a) => a.featured).slice(0, 3);
  const awards = achievements.filter((a) => a.category === 'Award');
  const employeeRecognition = achievements.filter((a) => a.category === 'Employee Recognition');
  const teamAchievements = achievements.filter((a) => a.category === 'Team Achievement');
  const milestones = achievements.filter((a) => a.category === 'Milestone');

  const peopleOf = (achievement) =>
    (achievement.employeeIds ?? []).map((id) => employeesById[id]).filter(Boolean);

  const timelineItems = achievements.slice(0, 12).map((achievement) => ({
    id: achievement.id,
    date: achievement.date,
    title: achievement.title,
    description: achievement.description,
    tone: achievement.category === 'Award' ? 'gold' : 'primary',
    meta: (
      <span className="u-cluster u-cluster--sm">
        <Badge tone="neutral">{achievement.category}</Badge>
        {teamsById[achievement.teamId] ? (
          <Badge tone="primary">{teamsById[achievement.teamId].shortName}</Badge>
        ) : null}
        {peopleOf(achievement).slice(0, 3).map((person) => (
          <Avatar key={person.id} name={person.fullName} src={person.photo} size="xs" />
        ))}
      </span>
    ),
  }));

  const renderGrid = (items, emptyMessage) =>
    items.length ? (
      <div className="grid-auto">
        {items.map((achievement, index) => (
          <div key={achievement.id} className={`u-anim-in u-delay-${(index % 9) + 1}`}>
            <AchievementCard
              achievement={achievement}
              teamName={teamsById[achievement.teamId]?.shortName}
              people={peopleOf(achievement)}
            />
          </div>
        ))}
      </div>
    ) : (
      <EmptyState icon="EmojiEvents" title="Nothing here yet" message={emptyMessage} />
    );

  return (
    <>
      {/* 1. Highlights ------------------------------------------------------- */}
      <section className="section section--tight">
        <div className="container-page u-stack u-stack--lg">
          <SectionHeading
            eyebrow="Celebrating success"
            eyebrowIcon="EmojiEvents"
            title="Achievement highlights"
            subtitle="The results the department is proudest of."
          />

          <div className="grid-auto grid-auto--4">
            <StatTile value={achievements.length} label="Total achievements" icon="EmojiEvents" />
            <StatTile value={awards.length} label="Awards won" icon="MilitaryTech" />
            <StatTile value={milestones.length} label="Milestones reached" icon="Flag" />
            <StatTile value={teamAchievements.length} label="Team achievements" icon="Groups" />
          </div>

          {highlights.length ? renderGrid(highlights, 'Feature an achievement from the admin panel.') : null}
        </div>
      </section>

      {/* Search / filter ------------------------------------------------------ */}
      <section className="section section--tight section--muted">
        <div className="container-page u-stack">
          <div className="filter-bar">
            <SearchInput value={term} onChange={setTerm} placeholder="Search achievements and awards..." />
            <div className="filter-bar__footer">
              <ChipFilters
                options={[
                  { value: ALL, label: 'All' },
                  ...ACHIEVEMENT_CATEGORIES.map((item) => ({ value: item, label: item })),
                ]}
                value={category}
                onChange={setCategory}
                ariaLabel="Filter achievements by category"
              />
              <span>
                <strong>{achievements.length}</strong> result(s)
              </span>
            </div>
          </div>

          <DataState
            isLoading={isLoading}
            error={error}
            isEmpty={achievements.length === 0}
            onRetry={refetch}
            skeletonCount={6}
            emptyProps={{
              icon: 'EmojiEvents',
              title: 'No achievements found',
              message: 'Try another category, or clear the search.',
              actionLabel: 'Clear',
              onAction: () => {
                setTerm('');
                setCategory(ALL);
              },
            }}
          >
            {renderGrid(achievements, 'Record the first achievement from the admin panel.')}
          </DataState>
        </div>
      </section>

      {/* 2. Awards ----------------------------------------------------------- */}
      <section className="section">
        <div className="container-page u-stack u-stack--lg">
          <SectionHeading
            eyebrow="Awards"
            eyebrowIcon="MilitaryTech"
            title="Awards"
            subtitle="Formal recognition earned inside and outside the department."
          />
          {renderGrid(awards, 'No awards recorded yet.')}
        </div>
      </section>

      {/* 3. Employee recognition --------------------------------------------- */}
      <section className="section section--muted">
        <div className="container-page u-stack u-stack--lg">
          <SectionHeading
            eyebrow="Individuals"
            eyebrowIcon="Person"
            title="Employee recognition"
            subtitle="Colleagues recognised for outstanding individual contribution."
          />
          {renderGrid(employeeRecognition, 'No individual recognition recorded yet.')}
        </div>
      </section>

      {/* 4. Team achievements ------------------------------------------------- */}
      <section className="section">
        <div className="container-page u-stack u-stack--lg">
          <SectionHeading
            eyebrow="Together"
            eyebrowIcon="Groups"
            title="Team achievements"
            subtitle="What our teams delivered as a unit."
          />
          {renderGrid(teamAchievements, 'No team achievements recorded yet.')}
        </div>
      </section>

      {/* 5. Department milestones --------------------------------------------- */}
      <section className="section section--muted">
        <div className="container-page u-stack u-stack--lg">
          <SectionHeading
            eyebrow="Milestones"
            eyebrowIcon="Flag"
            title="Department milestones"
            subtitle="Moments that marked a step change for the department."
          />
          {renderGrid(milestones, 'No milestones recorded yet.')}
        </div>
      </section>

      {/* 6. Recognition timeline ---------------------------------------------- */}
      <section className="section">
        <div className="container-page">
          <SectionHeading
            eyebrow="History"
            eyebrowIcon="Timeline"
            title="Recognition timeline"
            subtitle="Everything above, in the order it happened."
          />
          {timelineItems.length ? (
            <div className="card">
              <div className="card__body">
                <Timeline items={timelineItems} />
              </div>
            </div>
          ) : (
            <EmptyState icon="Timeline" title="Nothing on the timeline yet" message="Achievements will appear here as they are recorded." />
          )}
        </div>
      </section>
    </>
  );
}

export default AchievementsBoard;
