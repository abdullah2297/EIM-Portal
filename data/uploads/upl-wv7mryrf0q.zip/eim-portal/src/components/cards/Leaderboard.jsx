import Link from 'next/link';
import { Avatar } from '@/components/ui/Avatar';
import { EmptyState } from '@/components/ui/StateViews';
import { ROUTES } from '@/lib/constants';
import { formatNumber } from '@/lib/format';

/**
 * Competition leaderboard.
 *
 * @param {{
 *  entries: Array<{ rank: number, score: number, person: { id: string, fullName: string, jobTitle: string, photo?: string|null } | null }>,
 *  limit?: number,
 * }} props
 */
export function Leaderboard({ entries = [], limit }) {
  const rows = typeof limit === 'number' ? entries.slice(0, limit) : entries;

  if (!rows.length) {
    return (
      <EmptyState
        icon="Leaderboard"
        title="No scores yet"
        message="The leaderboard will appear here once the competition opens and the first entries are scored."
      />
    );
  }

  return (
    <ol className="u-stack u-stack--sm">
      {rows.map((entry) => (
        <li key={entry.person?.id ?? entry.rank} className={`leaderboard-row ${entry.rank <= 3 ? 'leaderboard-row--top' : ''}`.trim()}>
          <span className={`rank-medal ${entry.rank <= 3 ? `rank-medal--${entry.rank}` : ''}`.trim()}>
            {entry.rank}
          </span>
          {entry.person ? (
            <>
              <Avatar name={entry.person.fullName} src={entry.person.photo} size="sm" />
              <span className="leaderboard-row__name">
                <strong>
                  <Link href={ROUTES.employee(entry.person.id)}>{entry.person.fullName}</Link>
                </strong>
                <span>{entry.person.jobTitle}</span>
              </span>
            </>
          ) : (
            <span className="leaderboard-row__name">
              <strong>PLACEHOLDER - participant</strong>
              <span>Employee record not found</span>
            </span>
          )}
          <span className="leaderboard-row__score">{formatNumber(entry.score)}</span>
        </li>
      ))}
    </ol>
  );
}

export default Leaderboard;
