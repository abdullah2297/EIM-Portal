import { createResourceService } from './resourceService';
import { http } from './httpClient';
import { RESOURCES } from '@/lib/constants';
import { buildQuery } from '@/lib/query';

/**
 * The application's service layer.
 *
 * Components import from here and never touch `fetch` or a URL directly.
 */

export const teamsService = createResourceService(RESOURCES.teams);
export const subTeamsService = createResourceService(RESOURCES.subTeams);
export const employeesService = createResourceService(RESOURCES.employees);
export const initiativesService = createResourceService(RESOURCES.initiatives);
export const achievementsService = createResourceService(RESOURCES.achievements);
export const announcementsService = createResourceService(RESOURCES.announcements);
export const successStoriesService = createResourceService(RESOURCES.successStories);
export const competitionsService = createResourceService(RESOURCES.competitions);
export const galleryService = createResourceService(RESOURCES.gallery);
export const recognitionService = createResourceService(RESOURCES.recognition);
export const submissionsService = createResourceService(RESOURCES.submissions);

/** Resource name -> service, used by the schema-driven admin screens. */
export const SERVICE_BY_RESOURCE = {
  [RESOURCES.teams]: teamsService,
  [RESOURCES.subTeams]: subTeamsService,
  [RESOURCES.employees]: employeesService,
  [RESOURCES.initiatives]: initiativesService,
  [RESOURCES.achievements]: achievementsService,
  [RESOURCES.announcements]: announcementsService,
  [RESOURCES.successStories]: successStoriesService,
  [RESOURCES.competitions]: competitionsService,
  [RESOURCES.gallery]: galleryService,
  [RESOURCES.recognition]: recognitionService,
  [RESOURCES.submissions]: submissionsService,
};

export const departmentService = {
  async get() {
    const { data } = await http.get(`/api/${RESOURCES.department}`);
    return data;
  },
  async update(payload) {
    const { data } = await http.post(`/api/${RESOURCES.department}`, payload);
    return data;
  },
};

export const statsService = {
  async get() {
    const { data } = await http.get('/api/stats');
    return data;
  },
};

export const searchService = {
  /**
   * @param {string} term
   * @param {number} [limit] results per group
   */
  async search(term, limit) {
    const { data } = await http.get(`/api/search${buildQuery({ q: term, limit })}`);
    return data ?? { term, total: 0, groups: [] };
  },
};

export const contactService = {
  /** @param {{ name: string, email: string, type: string, subject: string, message: string }} payload */
  async submit(payload) {
    const { data } = await http.post('/api/contact', payload);
    return data;
  },
};

export const participationService = {
  /**
   * @param {{ competitionId: string, employeeId?: string, name: string, email: string, message?: string }} payload
   */
  async participate(payload) {
    const { data } = await http.post('/api/participate', payload);
    return data;
  },
};

export const authService = {
  async login(username, password) {
    const { data } = await http.post('/api/auth/login', { username, password });
    return data;
  },
  async logout() {
    const { data } = await http.post('/api/auth/logout');
    return data;
  },
  async session() {
    const { data } = await http.get('/api/auth/session');
    return data;
  },
};

export { ApiError } from './httpClient';
